/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ujian_pbo;

/**
 *
 * @author yubagrof
 */
public class mainfunction {
    public void listbuku(){
    }
    public void list_keranjang(){
    }
    public void clear() {
    }
    public boolean hitung(){
        return false;
    }
    public boolean pembayaran(String bayar){
        return false;
    }
    public void add_keranjang(String pilih){
    }
}
